#include "robot_supurge.h"
#include <iostream>

RobotSupurge::RobotSupurge(int speed, float batterylife, int x, int y) {
    this->speed = speed;
    this->batterylife = batterylife;
    this->map = {x, y};
}

void RobotSupurge::move(int x, int y, House &house) {
    // Engel kontrol durumunu burda sa�lamaya �al��t�m
    std::pair<int, int> obstacle = house.engelBul(x, y);
    if (obstacle.first != -1 && obstacle.second != -1) {
        std::cout << "Engel bulundu! Temizlik yap�lamad�. Koordinat: (" << x << ", " << y << ")" << std::endl;
        return;
    }

    // Oda kontrol durumunu burda ger�ekle�tirdim
    std::pair<int, int> room = house.odaBul(x, y);
    if (room.first != -1 && room.second != -1) {
        std::cout << "Robot, (" << x << ", " << y << ") koordinatindaki odayi temizledi!\n Oda Numarasi: ";
        for (size_t i = 0; i < house.rooms.size(); ++i) {
            if (house.rooms[i].first == room) {
                std::cout << i + 1;
                break;
            }
        }
        std::cout << std::endl;
    } else {
        std::cout << "Hareket edilen koordinat: (" << x << ", " << y << ")" << std::endl;//Supurgenin gittigi koordinat yaziyor
    }

    // �arj azalt
    for (int i = 0; i < x + y; i++) {
        this->batterylife -= 0.1;
    }
    std::cout << "Kalan Sarj: " << this->batterylife << std::endl;
}

