#include "house.h"

House::House(std::pair<int, int> map) {
    this->map = map;
}

std::pair<int, int> House::odaBul(int x, int y) {
    for (auto room : rooms) {
        if (room.first.first <= x && x <= room.second.first && room.first.second <= y && y <= room.second.second) {
            return {room.first.first, room.first.second};
        }
    }

    return {-1, -1};
}

std::pair<int, int> House::engelBul(int x, int y) {
    for (auto obstacle : obstacles) {
        if (obstacle.first == x && obstacle.second == y) {
            return obstacle;
        }
    }

    return {-1, -1};
}

