#ifndef ROBOT_SUPURGE_H
#define ROBOT_SUPURGE_H

#include "house.h"

class RobotSupurge {
public:
    int speed;
    float batterylife;
    std::pair<int, int> map;

    RobotSupurge(int speed, float batterylife, int x, int y);

    void move(int x, int y, House &house);

    float pilDurumunuKontrolEt();
};

#endif // ROBOT_SUPURGE_H
