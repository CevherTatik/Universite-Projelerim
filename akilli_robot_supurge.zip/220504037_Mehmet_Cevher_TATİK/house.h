#ifndef HOUSE_H
#define HOUSE_H

#include <vector>

class House {
public:
    std::pair<int, int> map;
    std::vector<std::pair<std::pair<int, int>, std::pair<int, int>>> rooms;
    std::vector<std::pair<int, int>> obstacles;

    House(std::pair<int, int> map);

    std::pair<int, int> odaBul(int x, int y);

    std::pair<int, int> engelBul(int x, int y);
};

#endif // HOUSE_H

