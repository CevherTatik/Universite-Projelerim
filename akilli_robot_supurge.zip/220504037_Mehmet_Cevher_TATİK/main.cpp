#include "robot_supurge.h"
#include "house.h"
#include <iostream>

int main() {
    // House nesnesini burda olu�turmaya �al��t�m
    while (1) {
        House house({100, 50});

        // Robot s�p�rgeyide burda tan�mlad�m
        RobotSupurge robotSupurge(5, 100, 0, 0);

        // Odalar�n house nesnesinin de�erlerini burdan girdim
        house.rooms.push_back({{0, 0}, {40, 15}});
        house.rooms.push_back({{0, 15}, {40, 35}});
        house.rooms.push_back({{0, 35}, {40, 50}});
        house.rooms.push_back({{40, 0}, {70, 15}});
        house.rooms.push_back({{70, 0}, {100, 15}});
        house.rooms.push_back({{70, 15}, {100, 50}});
        house.rooms.push_back({{40, 15}, {70, 25}});
        house.rooms.push_back({{40, 25}, {50, 35}});
        house.rooms.push_back({{50, 25}, {60, 35}});
        house.rooms.push_back({{60, 25}, {70, 50}});

        // Engelleri house nesnesine ekledim burda
        house.obstacles.push_back({10, 10});
        house.obstacles.push_back({30, 20});
        house.obstacles.push_back({60, 30});

        // burda kullan�c�dan gidilecek yeri istedim
        std::cout << "Gidilecek yeri giriniz (x, y): ";
        int x, y;
        std::cin >> x >> y;
        // burada robotu hareket tetirecek kodlar var
        robotSupurge.move(x, y, house);
    }
    return 0;
}
