// #define Sabitleri
#include <string.h>
#include <stdio.h>
#include "afetzede_yardim_sistemi.h"

#define MAX_AFETZEDE_SAYISI 100
#define MAX_ISIM_UZUNLUK 50
#define MAX_TELEFON_UZUNLUK 11
#define MAX_ADRES_UZUNLUK 100
#define MAX_TALEP_UZUNLUK 100
#define MAX_TALEP_SAYISI 100

// Global Degiskenler
char afetzede_isimleri[MAX_AFETZEDE_SAYISI][MAX_ISIM_UZUNLUK];
char afetzede_soyisimleri[MAX_AFETZEDE_SAYISI][MAX_ISIM_UZUNLUK];
char afetzede_telefonlari[MAX_AFETZEDE_SAYISI][MAX_TELEFON_UZUNLUK];
char afetzede_adresleri[MAX_AFETZEDE_SAYISI][MAX_ADRES_UZUNLUK];
int afetzede_sayisi;
char talep_aciklamalari[MAX_TALEP_SAYISI][MAX_TALEP_UZUNLUK];
int talep_afetzede_idleri[MAX_TALEP_SAYISI];
int talep_sayisi;

void afetzede_ekle(char *ad, char *soyad, char *telefon, char *adres) {
    if (afetzede_sayisi >= MAX_AFETZEDE_SAYISI) {
        printf("Hata: Afetzedeler listesi dolu.\n");
        return;
    }

    // Yeni afetzedeye ID numarası atama
    int id = afetzede_sayisi + 1;

    // Yeni afetzedeye ait bilgileri diziye ekleme
    strcpy(afetzede_isimleri[afetzede_sayisi], ad);
    strcpy(afetzede_soyisimleri[afetzede_sayisi], soyad);
    strcpy(afetzede_telefonlari[afetzede_sayisi], telefon);
    strcpy(afetzede_adresleri[afetzede_sayisi], adres);

    // Afetzedeler sayısını bir arttırma
    (afetzede_sayisi)++;
}

void afetzede_guncelle(int id, char *ad, char *soyad, char *telefon, char *adres) {
    if (id < 0 ) {
        printf("Hata: Yanlis afetzede ID'si girdiniz!\n");
        return;
    }
    strcpy(afetzede_isimleri[id-1], ad);
    strcpy(afetzede_soyisimleri[id-1], soyad);
    strcpy(afetzede_telefonlari[id-1], telefon);
    strcpy(afetzede_adresleri[id-1], adres);
    printf("Afetzede bilgileri guncellendi.\n");
}

void afetzede_sil(int id) {
    int i, j, silinecek_index = -1;

    // Silinecek afetzedeye ait index'i bulma
    for (i = 0; i < afetzede_sayisi; i++) {
        if (i + 1 == id) {
            silinecek_index = i;
            break;
        }
    }

    if (silinecek_index == -1) {
        printf("Hata: Gecerli bir afetzedeye ait ID numarasi giriniz.\n");
        return;
    }

    // Silinecek afetzedeyi dizi içinde kaydırma
    for (j = silinecek_index; j < afetzede_sayisi - 1; j++) {
        strcpy(afetzede_isimleri[j], afetzede_isimleri[j+1]);
        strcpy(afetzede_soyisimleri[j], afetzede_soyisimleri[j+1]);
        strcpy(afetzede_telefonlari[j], afetzede_telefonlari[j+1]);
        strcpy(afetzede_adresleri[j], afetzede_adresleri[j+1]);
    }

    // Afetzedeler sayısını bir azaltma
    (afetzede_sayisi)--;

    printf("ID=%d Numarali Afetzede silindi.\n",id);
}

void afetzede_ara(int id) {
    int kontrol=1;//eger donguye hic girmezse ID yoktur demektir bunu anlamak icin kontrol degıskeni kullandim
    int i;
    for( i=0; i<afetzede_sayisi; i++){
        if(i==id-1){
            printf("ID: %d\n", i+1);
            printf("Ad: %s\n", afetzede_isimleri[i]);
            printf("Soyad: %s\n", afetzede_soyisimleri[i]);
            printf("Telefon: %.11s\n", afetzede_telefonlari[i]);
            printf("Adres: %s\n", afetzede_adresleri[i]);
            printf("-----------------------\n");
            kontrol=0;
        }
    }
    if(kontrol==1){
        printf("ID BULUNAMADI\n");
    }
}

void afetzede_listele() {
    printf("----- Afetzedeler -----\n");
	int i;
    for ( i = 0; i < afetzede_sayisi; i++) {
        printf("ID: %d\n", i+1);
        printf("Ad: %s\n", afetzede_isimleri[i]);
        printf("Soyad: %s\n", afetzede_soyisimleri[i]);
        printf("Telefon: %.11s\n", afetzede_telefonlari[i]);
        printf("Adres: %s\n", afetzede_adresleri[i]);
        printf("-----------------------\n");
    }

    printf("Toplam %d afetzedeyi kaydetmis bulunmaktayiz.\n", afetzede_sayisi);
}

void yardim_talebi_kaydet(int id, char *aciklama) {
    if (talep_sayisi >= MAX_TALEP_SAYISI) {
        printf("Hata: Talep sayisi dolu.\n");
        return;
    }

    // Yeni talebi diziye ekleme
    strcpy(talep_aciklamalari[talep_sayisi], aciklama);
    talep_afetzede_idleri[talep_sayisi] = id;
    // Afetzede talep bir arttırma
    (talep_sayisi)++;

}

void yardim_talepleri_listele() {
    printf("----- Talepler -----\n");
	int i;
    for (i = 0; i < afetzede_sayisi; i++) {
        printf("ID: %d\n", i+1);
        printf("Talep: %s\n", talep_aciklamalari[i]);
        printf("-----------------------\n");
    }

    printf("Toplam %d afetzedeyi kaydetmis bulunmaktayiz.\n", afetzede_sayisi);
}

void menu_goster() {
    printf("\n1-Afetzede ekle \n");
    printf("2-Afetzede guncelle\n");
    printf("3-Afetzede sil\n");
    printf("4-Afetzede ara\n");
    printf("5-Afetzede listele\n");
    printf("6-Yardim talebini olustur\n");
    printf("7-Var olan yardim taleplerini listele\n");
    printf("8-Islemimi sonlandir\n");
    printf("Yapmak istedginiz islemin yanindaki sayiya basiniz:");
}

void hata_mesaji(){
    printf("Hatali islem yaptiniz!\n");

}
