#include <stdio.h>
#include <string.h>
#include "afetzede_yardim_sistemi.h"

#define MAX_ISIM_UZUNLUK 50
#define MAX_TELEFON_UZUNLUK 50
#define MAX_ADRES_UZUNLUK 100
#define MAX_TALEP_UZUNLUK 100

int main() {
    char isim[MAX_ISIM_UZUNLUK], soyisim[MAX_ISIM_UZUNLUK], numara[MAX_TELEFON_UZUNLUK], konum[MAX_ADRES_UZUNLUK];
    char talep[MAX_TALEP_UZUNLUK];
    int fonksiyonlar,a;

    printf("----Afetzede Otomasyonuna Hosgeldiniz----");
    menu_goster();

    while(1) {
        scanf("%d", &fonksiyonlar);
        switch (fonksiyonlar) {
            case 1://afetzede ekleme
                printf("Isim:");
                scanf("%s", &isim);
                printf("Soyisim:");
                scanf("%s", &soyisim);
                printf("telefon:");
                scanf("%s", &numara);
                printf("Il:");
                scanf("%s", &konum);
                afetzede_ekle(isim, soyisim, numara, konum);
                printf("Afetzede kaydedildi.\n");
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;

            case 2://afetzede guncelle
                printf("guncellemek istediginiz ID numarasini giriniz:");
                scanf("%d",&a);
                printf("Isim:");
                scanf("%s", &isim);
                printf("Soyisim:");
                scanf("%s", &soyisim);
                printf("telefon:");
                scanf("%s", &numara);
                printf("Il:");
                scanf("%s",&konum);
                afetzede_guncelle(a,isim,soyisim,numara,konum);
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;

            case 3://afetzede sil
                printf("Silmek istediginiz ID yi giriniz:");
                scanf("%d", &a);
                afetzede_sil((int) a);
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;

            case 4://afetzede ara
                printf("Aradiginiz ID yi giriniz:");
                scanf("%d", &a);
                afetzede_ara((int) a);
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;

            case 5://kayitli afetzedeleri gösterir
                afetzede_listele();
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;

            case 6://yardım talebi kaydetme
                printf("ID giriniz:");
                scanf("%d", &a);
                printf("Talebinizi tek kelime veya arasina bosluk yerine alt tire koyarak yaziniz(ornek:yastik veya yastik_hali): ");
                scanf("%s",&talep);
                yardim_talebi_kaydet( a, talep);
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;

            case 7://yardım taleplerini listeleme
                yardim_talepleri_listele();
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;
            case 8:
                printf("Isleminizi sonlandirdiniz hayirli ve saglikli gunler dileriz.:)");
                return 0;

            default:
                hata_mesaji();
                printf("-----------------------\n");
                printf("yapmak istediginiz islemi seciniz islemi sonlandirmak icin 8 basiniz:");
                break;
        }
    }
    return 0;
}
